from Technical.NSE import NSE
