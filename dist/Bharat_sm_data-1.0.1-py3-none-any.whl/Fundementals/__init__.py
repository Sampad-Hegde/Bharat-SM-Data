from Fundementals.MoneyControl import MoneyControl
from Fundementals.TickerTape import Tickertape